(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__9de9ecff._.css",
  "static/chunks/node_modules_@iota_12dde452._.js",
  "static/chunks/node_modules_@tanstack_query-core_build_modern_97963f45._.js",
  "static/chunks/node_modules_valibot_dist_index_67e898f2.js",
  "static/chunks/node_modules_@noble_curves_esm_112ba1bf._.js",
  "static/chunks/node_modules_@iota_dapp-kit_dist_esm_index_01b1c185.js",
  "static/chunks/node_modules_@radix-ui_cdebb1ee._.js",
  "static/chunks/node_modules_@iota_87909fdf._.js",
  "static/chunks/node_modules_@floating-ui_1b6e7b6d._.js",
  "static/chunks/node_modules_4840170c._.js",
  "static/chunks/_12b0b1c2._.js"
],
    source: "dynamic"
});
