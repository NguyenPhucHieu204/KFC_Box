(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_2a976c61._.js",
  "static/chunks/node_modules_1a60a296._.js"
],
    source: "dynamic"
});
